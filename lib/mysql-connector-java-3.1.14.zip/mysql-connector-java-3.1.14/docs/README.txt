
1. MySQL Connector/J
     _______________________________________________________

   MySQL provides connectivity for client applications developed in
   the Java programming language via a JDBC driver, which is called
   MySQL Connector/J.

   MySQL Connector/J is a JDBC-3.0 Type 4 driver, which means that is
   pure Java, implements version 3.0 of the JDBC specification, and
   communicates directly with the MySQL server using the MySQL
   protocol.

   Although JDBC is useful by itself, we would hope that if you are
   not familiar with JDBC that after reading the first few sections
   of this manual, that you would avoid using naked JDBC for all but
   the most trivial problems and consider using one of the popular
   persistence frameworks such as Hibernate
   (http://www.hibernate.org/), Spring's JDBC templates
   (http://www.springframework.org/) or Ibatis SQL Maps
   (http://ibatis.apache.org/) to do the majority of repetitive work
   and heavier lifting that is sometimes required with JDBC.

   This section is not designed to be a complete JDBC tutorial. If
   you need more information about using JDBC you might be interested
   in the following online tutorials that are more in-depth than the
   information presented here:
     * JDBC Basics
       (http://java.sun.com/docs/books/tutorial/jdbc/basics/index.htm
       l) --- A tutorial from Sun covering beginner topics in JDBC
     * JDBC Short Course
       (http://java.sun.com/developer/onlineTraining/Database/JDBCSho
       rtCourse/index.html) --- A more in-depth tutorial from Sun and
       JGuru

1.1. Connector/J Versions

   There are currently three version of MySQL Connector/J available:
     * Connector/J 3.0 provides core functionality and was designed
       with connectivity to MySQL 3.x or MySQL 4.1 servers, although
       it will provide basic compatibility with later versions of
       MySQL. Connector/J 3.0 does not support server-side prepared
       statements, and does not support any of the features in
       versions of MySQL later than 4.1.
     * Connector/J 3.1 was designed for connectivity to MySQL 4.1 and
       MySQL 5.0 servers and provides support for all the
       functionality in MySQL 5.0 except distributed transaction (XA)
       support.
     * Connector/J 5.0 provides support for all the functionality
       offered by Connector/J 3.1 and includes distributed
       transaction (XA) support.

   The current recommended version for Connector/J is 5.0. This guide
   covers all three connector versions, with specific notes given
   where a setting applies to a specific option.

1.1.1. Java Versions Supported

   MySQL Connector/J supports Java-2 JVMs, including:
     * JDK 1.2.x
     * JDK 1.3.x
     * JDK 1.4.x
     * JDK 1.5.x

   If you are building Connector/J from source using the source
   distribution (see Section A.2.4, "Installing from the Development
   Source Tree") then you must use JDK 1.4.x or newer to compiler the
   Connector package.

   MySQL Connector/J does not support JDK-1.1.x or JDK-1.0.x

   Because of the implementation of java.sql.Savepoint, Connector/J
   3.1.0 and newer will not run on JDKs older than 1.4 unless the
   class verifier is turned off (by setting the -Xverify:none option
   to the Java runtime). This is because the class verifier will try
   to load the class definition for java.sql.Savepoint even though it
   is not accessed by the driver unless you actually use savepoint
   functionality.

   Caching functionality provided by Connector/J 3.1.0 or newer is
   also not available on JVMs older than 1.4.x, as it relies on
   java.util.LinkedHashMap which was first available in JDK-1.4.0.

1.2. Installing Connector/J

   You can install the Connector/J package using two methods, using
   either the binary or source distribution. The binary distribution
   provides the easiest methods for installation; the source
   distribution enables you to customize your installation further.
   With with either solution, you must

1.2.1. Installing Connector/J from a Binary Distribution

   The easiest method of installation is to use the binary
   distribution of the Connector/J package. The binary distribution
   is available either as a Tar/Gzip or Zip file which you must
   extract to a suitable location and then optionally make the
   information about the package available by changing your CLASSPATH
   (see Section A.2.2, "Installing the Driver and Configuring the
   CLASSPATH").

   MySQL Connector/J is distributed as a .zip or .tar.gz archive
   containing the sources, the class files, and the JAR archive named
   mysql-connector-java-[version]-bin.jar, and starting with
   Connector/J 3.1.8 a debug build of the driver in a file named
   mysql-connector-java-[version]-bin-g.jar.

   Starting with Connector/J 3.1.9, the .class files that constitute
   the JAR files are only included as part of the driver JAR file.

   You should not use the debug build of the driver unless instructed
   to do so when reporting a problem ors bug to MySQL AB, as it is
   not designed to be run in production environments, and will have
   adverse performance impact when used. The debug binary also
   depends on the Aspect/J runtime library, which is located in the
   src/lib/aspectjrt.jar file that comes with the Connector/J
   distribution.

   You will need to use the appropriate graphical or command-line
   utility to un-archive the distribution (for example, WinZip for
   the .zip archive, and tar for the .tar.gz archive). Because there
   are potentially long filenames in the distribution, we use the GNU
   tar archive format. You will need to use GNU tar (or an
   application that understands the GNU tar archive format) to unpack
   the .tar.gz variant of the distribution.

1.2.2. Installing the Driver and Configuring the CLASSPATH

   Once you have extracted the distribution archive, you can install
   the driver by placing mysql-connector-java-[version]-bin.jar in
   your classpath, either by adding the full path to it to your
   CLASSPATH environment variable, or by directly specifying it with
   the command line switch -cp when starting your JVM.

   If you are going to use the driver with the JDBC DriverManager,
   you would use com.mysql.jdbc.Driver as the class that implements
   java.sql.Driver.

   You can set the CLASSPATH environment variableunder UNIX, Linux or
   Mac OS X either locally for a user within their .profile, .login
   or other login file. You can also set it globally by editing the
   global /etc/profile file.

   For example, under a C shell (csh, tcsh) you would add the
   Connector/J driver to your CLASSPATH using the following:
shell> setenv CLASSPATH /path/to/mysql-connector-java-[version]-bin.j
ar:$CLASSPATH

   Or with a Bourne-compatible shell (sh, ksh, bash):
export set CLASSPATH=/path/to/mysql-connector-java-[version]-bin.jar:
$CLASSPATH

   Within Windows 2000, Windows XP and Windows Server 2003, you must
   set the environment variable through the System control panel.

   If you want to use MySQL Connector/J with an application server
   such as Tomcat or JBoss, you will have to read your vendor's
   documentation for more information on how to configure third-party
   class libraries, as most application servers ignore the CLASSPATH
   environment variable. For configuration examples for some J2EE
   application servers, see Section A.5.2, "Using Connector/J with
   J2EE and Other Java Frameworks." However, the authoritative source
   for JDBC connection pool configuration information for your
   particular application server is the documentation for that
   application server.

   If you are developing servlets or JSPs, and your application
   server is J2EE-compliant, you can put the driver's .jar file in
   the WEB-INF/lib subdirectory of your webapp, as this is a standard
   location for third party class libraries in J2EE web applications.

   You can also use the MysqlDataSource or
   MysqlConnectionPoolDataSource classes in the
   com.mysql.jdbc.jdbc2.optional package, if your J2EE application
   server supports or requires them. Starting with Connector/J 5.0.0,
   the javax.sql.XADataSource interface is implemented via the
   com.mysql.jdbc.jdbc2.optional.MysqlXADataSource class, which
   supports XA distributed transactions when used in combination with
   MySQL server version 5.0.

   The various MysqlDataSource classes support the following
   parameters (through standard set mutators):
     * user
     * password
     * serverName (see the previous section about fail-over hosts)
     * databaseName
     * port

1.2.3. Upgrading from an Older Version

   MySQL AB tries to keep the upgrade process as easy as possible,
   however as is the case with any software, sometimes changes need
   to be made in new versions to support new features, improve
   existing functionality, or comply with new standards.

   This section has information about what users who are upgrading
   from one version of Connector/J to another (or to a new version of
   the MySQL server, with respect to JDBC functionality) should be
   aware of.

1.2.3.1. Upgrading from MySQL Connector/J 3.0 to 3.1

   Connector/J 3.1 is designed to be backward-compatible with
   Connector/J 3.0 as much as possible. Major changes are isolated to
   new functionality exposed in MySQL-4.1 and newer, which includes
   Unicode character sets, server-side prepared statements, SQLState
   codes returned in error messages by the server and various
   performance enhancements that can be enabled or disabled via
   configuration properties.
     * Unicode Character Sets --- See the next section, as well as
       Character Set Support
       (http://dev.mysql.com/doc/refman/5.0/en/charset.html), for
       information on this new feature of MySQL. If you have
       something misconfigured, it will usually show up as an error
       with a message similar to Illegal mix of collations.
     * Server-side Prepared Statements --- Connector/J 3.1 will
       automatically detect and use server-side prepared statements
       when they are available (MySQL server version 4.1.0 and
       newer).
       Starting with version 3.1.7, the driver scans SQL you are
       preparing via all variants of Connection.prepareStatement() to
       determine if it is a supported type of statement to prepare on
       the server side, and if it is not supported by the server, it
       instead prepares it as a client-side emulated prepared
       statement. You can disable this feature by passing
       emulateUnsupportedPstmts=false in your JDBC URL.
       If your application encounters issues with server-side
       prepared statements, you can revert to the older client-side
       emulated prepared statement code that is still presently used
       for MySQL servers older than 4.1.0 with the connection
       property useServerPrepStmts=false
     * Datetimes with all-zero components (0000-00-00 ...) --- These
       values can not be represented reliably in Java. Connector/J
       3.0.x always converted them to NULL when being read from a
       ResultSet.
       Connector/J 3.1 throws an exception by default when these
       values are encountered as this is the most correct behavior
       according to the JDBC and SQL standards. This behavior can be
       modified using the zeroDateTimeBehavior configuration
       property. The allowable values are:
          + exception (the default), which throws an SQLException
            with an SQLState of S1009.
          + convertToNull, which returns NULL instead of the date.
          + round, which rounds the date to the nearest closest value
            which is 0001-01-01.
       Starting with Connector/J 3.1.7, ResultSet.getString() can be
       decoupled from this behavior via noDatetimeStringSync=true
       (the default value is false) so that you can get retrieve the
       unaltered all-zero value as a String. It should be noted that
       this also precludes using any time zone conversions, therefore
       the driver will not allow you to enable noDatetimeStringSync
       and useTimezone at the same time.
     * New SQLState Codes --- Connector/J 3.1 uses SQL:1999 SQLState
       codes returned by the MySQL server (if supported), which are
       different from the legacy X/Open state codes that Connector/J
       3.0 uses. If connected to a MySQL server older than
       MySQL-4.1.0 (the oldest version to return SQLStates as part of
       the error code), the driver will use a built-in mapping. You
       can revert to the old mapping by using the configuration
       property useSqlStateCodes=false.
     * ResultSet.getString() --- Calling ResultSet.getString() on a
       BLOB column will now return the address of the byte[] array
       that represents it, instead of a String representation of the
       BLOB. BLOBs have no character set, so they can't be converted
       to java.lang.Strings without data loss or corruption.
       To store strings in MySQL with LOB behavior, use one of the
       TEXT types, which the driver will treat as a java.sql.Clob.
     * Debug builds --- Starting with Connector/J 3.1.8 a debug build
       of the driver in a file named
       mysql-connector-java-[version]-bin-g.jar is shipped alongside
       the normal binary jar file that is named
       mysql-connector-java-[version]-bin.jar.
       Starting with Connector/J 3.1.9, we don't ship the .class
       files unbundled, they are only available in the JAR archives
       that ship with the driver.
       You should not use the debug build of the driver unless
       instructed to do so when reporting a problem or bug to MySQL
       AB, as it is not designed to be run in production
       environments, and will have adverse performance impact when
       used. The debug binary also depends on the Aspect/J runtime
       library, which is located in the src/lib/aspectjrt.jar file
       that comes with the Connector/J distribution.

1.2.3.2. JDBC-Specific Issues When Upgrading to MySQL Server 4.1 or
Newer

     * Using the UTF-8 Character Encoding - Prior to MySQL server
       version 4.1, the UTF-8 character encoding was not supported by
       the server, however the JDBC driver could use it, allowing
       storage of multiple character sets in latin1 tables on the
       server.
       Starting with MySQL-4.1, this functionality is deprecated. If
       you have applications that rely on this functionality, and can
       not upgrade them to use the official Unicode character support
       in MySQL server version 4.1 or newer, you should add the
       following property to your connection URL:
       useOldUTF8Behavior=true
     * Server-side Prepared Statements - Connector/J 3.1 will
       automatically detect and use server-side prepared statements
       when they are available (MySQL server version 4.1.0 and
       newer). If your application encounters issues with server-side
       prepared statements, you can revert to the older client-side
       emulated prepared statement code that is still presently used
       for MySQL servers older than 4.1.0 with the following
       connection property:
       useServerPrepStmts=false

1.2.4. Installing from the Development Source Tree

   Caution.  You should read this section only if you are interested
   in helping us test our new code. If you just want to get MySQL
   Connector/J up and running on your system, you should use a
   standard release distribution.

   To install MySQL Connector/J from the development source tree,
   make sure that you have the following prerequisites:
     * Subversion, to check out the sources from our repository
       (available from http://subversion.tigris.org/).
     * Apache Ant version 1.6 or newer (available from
       http://ant.apache.org/).
     * JDK-1.4.2 or later. Although MySQL Connector/J can be
       installed on older JDKs, to compile it from source you must
       have at least JDK-1.4.2.

   The Subversion source code repository for MySQL Connector/J is
   located at http://svn.mysql.com/svnpublic/connector-j. In general,
   you should not check out the entire repository because it contains
   every branch and tag for MySQL Connector/J and is quite large.

   To check out and compile a specific branch of MySQL Connector/J,
   follow these steps:
    1. At the time of this writing, there are three active branches
       of Connector/J: branch_3_0, branch_3_1 and branch_5_0. Check
       out the latest code from the branch that you want with the
       following command (replacing [major] and [minor] with
       appropriate version numbers):
shell> svn co »
http://svn.mysql.com/svnpublic/connector-j/branches/branch_[major]_[m
inor]/connector-j
       This creates a connector-j subdirectory in the current
       directory that contains the latest sources for the requested
       branch.
    2. Change location to the connector-j directory to make it your
       current working directory:
shell> cd connector-j
    3. Issue the following command to compile the driver and create a
       .jar file suitable for installation:
shell> ant dist
       This creates a build directory in the current directory, where
       all build output will go. A directory is created in the build
       directory that includes the version number of the sources you
       are building from. This directory contains the sources,
       compiled .class files, and a .jar file suitable for
       deployment. For other possible targets, including ones that
       will create a fully packaged distribution, issue the following
       command:
shell> ant --projecthelp
    4. A newly created .jar file containing the JDBC driver will be
       placed in the directory build/mysql-connector-java-[version].
       Install the newly created JDBC driver as you would a binary
       .jar file that you download from MySQL by following the
       instructions in Section A.2.2, "Installing the Driver and
       Configuring the CLASSPATH."

1.3. Connector/J Examples

   Examples of using Connector/J are located throughout this
   document, this section provides a summary and links to these
   examples.
     * Section A.5.1.1, "Obtaining a connection from the
       DriverManager"
     * Section A.5.1.2, "Using java.sql.Statement to execute a SELECT
       query"
     * Section A.5.1.3, "Stored Procedures"
     * Section A.5.1.3, "Using Connection.prepareCall()"
     * Section A.5.1.3, "Registering output parameters"
     * Section A.5.1.3, "Setting CallableStatement input parameters"
     * Section A.5.1.3, "Retrieving results and output parameter
       values"
     * Section A.5.1.4, "Retrieving AUTO_INCREMENT column values
       using Statement.getGeneratedKeys()"
     * Section A.5.1.4, "Retrieving AUTO_INCREMENT column values
       using SELECT LAST_INSERT_ID()"
     * Section A.5.1.4, "Retrieving AUTO_INCREMENT column values in
       Updatable ResultSets"
     * Section A.5.2.1.1, "Using a connection pool with a J2EE
       application server"
     * Section A.5.3, "Example of transaction with retry logic"

1.4. Connector/J (JDBC) Reference

   This section of the manual contains reference material for MySQL
   Connector/J, some of which is automatically generated during the
   Connector/J build process.

1.4.1. Driver/Datasource Class Names, URL Syntax and Configuration
Properties for Connector/J

   The name of the class that implements java.sql.Driver in MySQL
   Connector/J is com.mysql.jdbc.Driver. The org.gjt.mm.mysql.Driver
   class name is also usable to remain backward-compatible with
   MM.MySQL. You should use this class name when registering the
   driver, or when otherwise configuring software to use MySQL
   Connector/J.

   The JDBC URL format for MySQL Connector/J is as follows, with
   items in square brackets ([, ]) being optional:
jdbc:mysql://[host][,failoverhost...][:port]/[database] »
[?propertyName1][=propertyValue1][&propertyName2][=propertyValue2]...

   If the hostname is not specified, it defaults to 127.0.0.1. If the
   port is not specified, it defaults to 3306, the default port
   number for MySQL servers.
jdbc:mysql://[host:port],[host:port].../[database] »
[?propertyName1][=propertyValue1][&propertyName2][=propertyValue2]...

   If the database is not specified, the connection will be made with
   no default database. In this case, you will need to either call
   the setCatalog() method on the Connection instance or
   fully-specify table names using the database name (i.e. SELECT
   dbname.tablename.colname FROM dbname.tablename...) in your SQL.
   Not specifying the database to use upon connection is generally
   only useful when building tools that work with multiple databases,
   such as GUI database managers.

   MySQL Connector/J has fail-over support. This allows the driver to
   fail-over to any number of slave hosts and still perform read-only
   queries. Fail-over only happens when the connection is in an
   autoCommit(true) state, because fail-over can not happen reliably
   when a transaction is in progress. Most application servers and
   connection pools set autoCommit to true at the end of every
   transaction/connection use.

   The fail-over functionality has the following behavior:
     * If the URL property autoReconnect is false: Failover only
       happens at connection initialization, and failback occurs when
       the driver determines that the first host has become available
       again.
     * If the URL property autoReconnect is true: Failover happens
       when the driver determines that the connection has failed
       (before every query), and falls back to the first host when it
       determines that the host has become available again (after
       queriesBeforeRetryMaster queries have been issued).

   In either case, whenever you are connected to a "failed-over"
   server, the connection will be set to read-only state, so queries
   that would modify data will have exceptions thrown (the query will
   never be processed by the MySQL server).

   Configuration properties define how Connector/J will make a
   connection to a MySQL server. Unless otherwise noted, properties
   can be set for a DataSource object or for a Connection object.

   Configuration Properties can be set in one of the following ways:
     * Using the set*() methods on MySQL implementations of
       java.sql.DataSource (which is the preferred method when using
       implementations of java.sql.DataSource):
          + com.mysql.jdbc.jdbc2.optional.MysqlDataSource
          + com.mysql.jdbc.jdbc2.optional.MysqlConnectionPoolDataSour
            ce
     * As a key/value pair in the java.util.Properties instance
       passed to DriverManager.getConnection() or Driver.connect()
     * As a JDBC URL parameter in the URL given to
       java.sql.DriverManager.getConnection(),
       java.sql.Driver.connect() or the MySQL implementations of the
       javax.sql.DataSource setURL() method.
       Note.  If the mechanism you use to configure a JDBC URL is
       XML-based, you will need to use the XML character literal
       &amp; to separate configuration parameters, as the ampersand
       is a reserved character for XML.

   The properties are listed in the following tables.

   Connection/Authentication. 
   Property Name Definition Default Value Since Version
   user The user to connect as   all
   password The password to use when connecting   all
   socketFactory The name of the class that the driver should use for
   creating socket connections to the server. This class must
   implement the interface com.mysql.jdbc.SocketFactory and have
   public no-args constructor. com.mysql.jdbc.StandardSocketFactory
   3.0.3
   connectTimeout Timeout for socket connect (in milliseconds), with
   0 being no timeout. Only works on JDK-1.4 or newer. Defaults to 0.
   0 3.0.1
   socketTimeout Timeout on network socket operations (0, the default
   means no timeout). 0 3.0.1
   useConfigs Load the comma-delimited list of configuration
   properties before parsing the URL or applying user-specified
   properties. See Section A.4.1, "Driver/Datasource Class Names, URL
   Syntax and Configuration Properties for Connector/J"   3.1.5
   interactiveClient Set the CLIENT_INTERACTIVE flag, which tells
   MySQL to timeout connections based on INTERACTIVE_TIMEOUT instead
   of WAIT_TIMEOUT false 3.1.0
   propertiesTransform An implementation of
   com.mysql.jdbc.ConnectionPropertiesTransform that the driver will
   use to modify URL properties passed to the driver before
   attempting a connection   3.1.4
   useCompression Use zlib compression when communicating with the
   server (true/false)? Defaults to false. false 3.0.17

   High Availability and Clustering. 
   Property Name Definition Default Value Since Version
   autoReconnect Should the driver try to re-establish stale and/or
   dead connections? If enabled the driver will throw an exception
   for a queries issued on a stale or dead connection, which belong
   to the current transaction, but will attempt reconnect before the
   next query issued on the connection in a new transaction. The use
   of this feature is not recommended, because it has side effects
   related to session state and data consistency when applications
   don'thandle SQLExceptions properly, and is only designed to be
   used when you are unable to configure your application to handle
   SQLExceptions resulting from dead andstale connections properly.
   Alternatively, investigate setting the MySQL server variable
   "wait_timeout"to some high value rather than the default of 8
   hours. false 1.1
   autoReconnectForPools Use a reconnection strategy appropriate for
   connection pools (defaults to 'false') false 3.1.3
   failOverReadOnly When failing over in autoReconnect mode, should
   the connection be set to 'read-only'? true 3.0.12
   reconnectAtTxEnd If autoReconnect is set to true, should the
   driver attempt reconnectionsat the end of every transaction? false
   3.0.10
   roundRobinLoadBalance When autoReconnect is enabled, and
   failoverReadonly is false, should we pick hosts to connect to on a
   round-robin basis? false 3.1.2
   queriesBeforeRetryMaster Number of queries to issue before falling
   back to master when failed over (when using multi-host failover).
   Whichever condition is met first, 'queriesBeforeRetryMaster' or
   'secondsBeforeRetryMaster' will cause an attempt to be made to
   reconnect to the master. Defaults to 50. 50 3.0.2
   secondsBeforeRetryMaster How long should the driver wait, when
   failed over, before attempting to reconnect to the master server?
   Whichever condition is met first, 'queriesBeforeRetryMaster' or
   'secondsBeforeRetryMaster' will cause an attempt to be made to
   reconnect to the master. Time in seconds, defaults to 30 30 3.0.2
   resourceId A globally unique name that identifies the resource
   that this datasource or connection is connected to, used for
   XAResource.isSameRM() when the driver can't determine this value
   based on hostnames used in the URL   5.0.1

   Security. 
   Property Name Definition Default Value Since Version
   allowMultiQueries Allow the use of ';' to delimit multiple queries
   during one statement (true/false, defaults to 'false' false 3.1.1
   useSSL Use SSL when communicating with the server (true/false),
   defaults to 'false' false 3.0.2
   requireSSL Require SSL connection if useSSL=true? (defaults to
   'false'). false 3.1.0
   allowUrlInLocalInfile Should the driver allow URLs in 'LOAD DATA
   LOCAL INFILE' statements? false 3.1.4
   paranoid Take measures to prevent exposure sensitive information
   in error messages and clear data structures holding sensitive data
   when possible? (defaults to 'false') false 3.0.1

   Performance Extensions. 
   Property Name Definition Default Value Since Version
   metadataCacheSize The number of queries to cacheResultSetMetadata
   for if cacheResultSetMetaData is set to 'true' (default 50) 50
   3.1.1
   prepStmtCacheSize If prepared statement caching is enabled, how
   many prepared statements should be cached? 25 3.0.10
   prepStmtCacheSqlLimit If prepared statement caching is enabled,
   what's the largest SQL the driver will cache the parsing for? 256
   3.0.10
   useCursorFetch If connected to MySQL > 5.0.2, and setFetchSize() >
   0 on a statement, should that statement use cursor-based fetching
   to retrieve rows? false 5.0.0
   blobSendChunkSize Chunk to use when sending BLOB/CLOBs via
   ServerPreparedStatements 1048576 3.1.9
   cacheCallableStmts Should the driver cache the parsing stage of
   CallableStatements false 3.1.2
   cachePrepStmts Should the driver cache the parsing stage of
   PreparedStatements of client-side prepared statements, the check
   for suitability of server-side prepared and server-side prepared
   statements themselves? false 3.0.10
   cacheResultSetMetadata Should the driver cache ResultSetMetaData
   for Statements and PreparedStatements? (Req. JDK-1.4+, true/false,
   default 'false') false 3.1.1
   cacheServerConfiguration Should the driver cache the results of
   SHOW VARIABLES and SHOW COLLATION on a per-URL basis? false 3.1.5
   defaultFetchSize The driver will call setFetchSize(n) with this
   value on all newly-created Statements 0 3.1.9
   dontTrackOpenResources The JDBC specification requires the driver
   to automatically track and close resources, however if your
   application doesn't do a good job of explicitly calling close() on
   statements or result sets, this can cause memory leakage. Setting
   this property to true relaxes this constraint, and can be more
   memory efficient for some applications. false 3.1.7
   dynamicCalendars Should the driver retrieve the default calendar
   when required, or cache it per connection/session? false 3.1.5
   elideSetAutoCommits If using MySQL-4.1 or newer, should the driver
   only issue 'set autocommit=n' queries when the server's state
   doesn't match the requested state by
   Connection.setAutoCommit(boolean)? false 3.1.3
   holdResultsOpenOverStatementClose Should the driver close result
   sets on Statement.close() as required by the JDBC specification?
   false 3.1.7
   locatorFetchBufferSize If 'emulateLocators' is configured to
   'true', what size buffer should be used when fetching BLOB data
   for getBinaryInputStream? 1048576 3.2.1
   rewriteBatchedStatements Should the driver use multiqueries
   (irregardless of the setting of allowMultiQueries) as well as
   rewriting of prepared statements for INSERT into multi-value
   inserts when executeBatch() is called? Notice that this has the
   potential for SQL injection if using plain java.sql.Statements and
   your code doesn't sanitize input correctly. Notice that for
   prepared statements, server-side prepared statements can not
   currently take advantage of this rewrite option, and that if you
   don't specify stream lengths when using
   PreparedStatement.set*Stream(),the driver won't be able to
   determine the optimium number of parameters per batch and you
   might receive anan error from the driver that the resultant packet
   is too large. Statement.getGeneratedKeys() for these rewritten
   statements only works when the entire batch includes INSERT
   statements. false 3.1.13
   useFastIntParsing Use internal String->Integer conversion routines
   to avoid excessive object creation? true 3.1.4
   useJvmCharsetConverters Always use the character encoding routines
   built into the JVM, rather than using lookup tables for
   single-byte character sets? (The default of "true" for this is
   appropriate for newer JVMs true 5.0.1
   useLocalSessionState Should the driver refer to the internal
   values of autocommit and transaction isolation that are set by
   Connection.setAutoCommit() and
   Connection.setTransactionIsolation(), rather than querying the
   database? false 3.1.7
   useReadAheadInput Use newer, optimized non-blocking, buffered
   input stream when reading from the server? true 3.1.5

   Debuging/Profiling. 
   Property Name Definition Default Value Since Version
   logger The name of a class that implements
   'com.mysql.jdbc.log.Log' that will be used to log messages
   to.(default is 'com.mysql.jdbc.log.StandardLogger', which logs to
   STDERR) com.mysql.jdbc.log.StandardLogger 3.1.1
   profileSQL Trace queries and their execution/fetch times to the
   configured logger (true/false) defaults to 'false' false 3.1.0
   reportMetricsIntervalMillis If 'gatherPerfMetrics' is enabled, how
   often should they be logged (in ms)? 30000 3.1.2
   maxQuerySizeToLog Controls the maximum length/size of a query that
   will get logged when profiling or tracing 2048 3.1.3
   packetDebugBufferSize The maximum number of packets to retain when
   'enablePacketDebug' is true 20 3.1.3
   slowQueryThresholdMillis If 'logSlowQueries' is enabled, how long
   should a query (in ms) before it is logged as 'slow'? 2000 3.1.2
   useUsageAdvisor Should the driver issue 'usage' warnings advising
   proper and efficient usage of JDBC and MySQL Connector/J to the
   log (true/false, defaults to 'false')? false 3.1.1
   autoGenerateTestcaseScript Should the driver dump the SQL it is
   executing, including server-side prepared statements to STDERR?
   false 3.1.9
   dumpMetadataOnColumnNotFound Should the driver dump the
   field-level metadata of a result set into the exception message
   when ResultSet.findColumn() fails? false 3.1.13
   dumpQueriesOnException Should the driver dump the contents of the
   query sent to the server in the message for SQLExceptions? false
   3.1.3
   enablePacketDebug When enabled, a ring-buffer of
   'packetDebugBufferSize' packets will be kept, and dumped when
   exceptions are thrown in key areas in the driver's code false
   3.1.3
   explainSlowQueries If 'logSlowQueries' is enabled, should the
   driver automatically issue an 'EXPLAIN' on the server and send the
   results to the configured log at a WARN level? false 3.1.2
   logSlowQueries Should queries that take longer than
   'slowQueryThresholdMillis' be logged? false 3.1.2
   traceProtocol Should trace-level network protocol be logged? false
   3.1.2

   Miscellaneous. 
   Property Name Definition Default Value Since Version
   useUnicode Should the driver use Unicode character encodings when
   handling strings? Should only be used when the driver can't
   determine the character set mapping, or you are trying to 'force'
   the driver to use a character set that MySQL either doesn't
   natively support (such as UTF-8), true/false, defaults to 'true'
   true 1.1g
   characterEncoding If 'useUnicode' is set to true, what character
   encoding should the driver use when dealing with strings?
   (defaults is to 'autodetect')   1.1g
   characterSetResults Character set to tell the server to return
   results as.   3.0.13
   connectionCollation If set, tells the server to use this collation
   via 'set collation_connection'   3.0.13
   sessionVariables A comma-separated list of name/value pairs to be
   sent as SET SESSION ... to the server when the driver connects.
   3.1.8
   allowNanAndInf Should the driver allow NaN or +/- INF values in
   PreparedStatement.setDouble()? false 3.1.5
   autoClosePStmtStreams Should the driver automatically call
   .close() on streams/readers passed as arguments via set*()
   methods? false 3.1.12
   autoDeserialize Should the driver automatically detect and
   de-serialize objects stored in BLOB fields? false 3.1.5
   capitalizeTypeNames Capitalize type names in DatabaseMetaData?
   (usually only useful when using WebObjects, true/false, defaults
   to 'false') false 2.0.7
   clobCharacterEncoding The character encoding to use for sending
   and retrieving TEXT, MEDIUMTEXT and LONGTEXT values instead of the
   configured connection characterEncoding   5.0.0
   clobberStreamingResults This will cause a 'streaming' ResultSet to
   be automatically closed, and any outstanding data still streaming
   from the server to be discarded if another query is executed
   before all the data has been read from the server. false 3.0.9
   continueBatchOnError Should the driver continue processing batch
   commands if one statement fails. The JDBC spec allows either way
   (defaults to 'true'). true 3.0.3
   createDatabaseIfNotExist Creates the database given in the URL if
   it doesn't yet exist. Assumes the configured user has permissions
   to create databases. false 3.1.9
   emptyStringsConvertToZero Should the driver allow conversions from
   empty string fields to numeric values of '0'? true 3.1.8
   emulateLocators N/A false 3.1.0
   emulateUnsupportedPstmts Should the driver detect prepared
   statements that are not supported by the server, and replace them
   with client-side emulated versions? true 3.1.7
   ignoreNonTxTables Ignore non-transactional table warning for
   rollback? (defaults to 'false'). false 3.0.9
   jdbcCompliantTruncation Should the driver throw
   java.sql.DataTruncation exceptions when data is truncated as is
   required by the JDBC specification when connected to a server that
   supports warnings(MySQL 4.1.0 and newer)? true 3.1.2
   maxRows The maximum number of rows to return (0, the default means
   return all rows). -1 all versions
   noAccessToProcedureBodies When determining procedure parameter
   types for CallableStatements, and the connected user can't access
   procedure bodies through "SHOW CREATE PROCEDURE" or select on
   mysql.proc should the driver instead create basic metadata (all
   parameters reported as INOUT VARCHARs) instead of throwing an
   exception? false 5.0.3
   noDatetimeStringSync Don't ensure that
   ResultSet.getDatetimeType().toString().equals(ResultSet.getString(
   )) false 3.1.7
   noTimezoneConversionForTimeType Don't convert TIME values using
   the server timezone if 'useTimezone'='true' false 5.0.0
   nullCatalogMeansCurrent When DatabaseMetadataMethods ask for a
   'catalog' parameter, does the value null mean use the current
   catalog? (this is not JDBC-compliant, but follows legacy behavior
   from earlier versions of the driver) true 3.1.8
   nullNamePatternMatchesAll Should DatabaseMetaData methods that
   accept *pattern parameters treat null the same as '%' (this is not
   JDBC-compliant, however older versions of the driver accepted this
   departure from the specification) true 3.1.8
   overrideSupportsIntegrityEnhancementFacility Should the driver
   return "true" for
   DatabaseMetaData.supportsIntegrityEnhancementFacility() even if
   the database doesn't support it to workaround applications that
   require this method to return "true" to signal support of foreign
   keys, even though the SQL specification states that this facility
   contains much more than just foreign key support (one such
   application being OpenOffice)? false 3.1.12
   pedantic Follow the JDBC spec to the letter. false 3.0.0
   pinGlobalTxToPhysicalConnection When using XAConnections, should
   the driver ensure that operations on a given XID are always routed
   to the same physical connection? This allows the XAConnection to
   support "XA START ... JOIN" after "XA END" has been called false
   5.0.1
   processEscapeCodesForPrepStmts Should the driver process escape
   codes in queries that are prepared? true 3.1.12
   relaxAutoCommit If the version of MySQL the driver connects to
   does not support transactions, still allow calls to commit(),
   rollback() and setAutoCommit() (true/false, defaults to 'false')?
   false 2.0.13
   retainStatementAfterResultSetClose Should the driver retain the
   Statement reference in a ResultSet after ResultSet.close() has
   been called. This is not JDBC-compliant after JDBC-4.0. false
   3.1.11
   rollbackOnPooledClose Should the driver issue a rollback() when
   the logical connection in a pool is closed? true 3.0.15
   runningCTS13 Enables workarounds for bugs in Sun's JDBC compliance
   testsuite version 1.3 false 3.1.7
   serverTimezone Override detection/mapping of timezone. Used when
   timezone from server doesn't map to Java timezone   3.0.2
   strictFloatingPoint Used only in older versions of compliance test
   false 3.0.0
   strictUpdates Should the driver do strict checking (all primary
   keys selected) of updatable result sets (true, false, defaults to
   'true')? true 3.0.4
   tinyInt1isBit Should the driver treat the datatype TINYINT(1) as
   the BIT type (because the server silently converts BIT ->
   TINYINT(1) when creating tables)? true 3.0.16
   transformedBitIsBoolean If the driver converts TINYINT(1) to a
   different type, should it use BOOLEAN instead of BIT for future
   compatibility with MySQL-5.0, as MySQL-5.0 has a BIT type? false
   3.1.9
   ultraDevHack Create PreparedStatements for prepareCall() when
   required, because UltraDev is broken and issues a prepareCall()
   for _all_ statements? (true/false, defaults to 'false') false
   2.0.3
   useGmtMillisForDatetimes Convert between session timezone and GMT
   before creating Date and Timestamp instances (value of "false" is
   legacy behavior, "true" leads to more JDBC-compliant behavior.
   false 3.1.12
   useHostsInPrivileges Add '@hostname' to users in
   DatabaseMetaData.getColumn/TablePrivileges() (true/false),
   defaults to 'true'. true 3.0.2
   useInformationSchema When connected to MySQL-5.0.7 or newer,
   should the driver use the INFORMATION_SCHEMA to derive information
   used by DatabaseMetaData? false 5.0.0
   useJDBCCompliantTimezoneShift Should the driver use JDBC-compliant
   rules when converting TIME/TIMESTAMP/DATETIME values' timezone
   information for those JDBC arguments which take a
   java.util.Calendar argument? (Notice that this option is exclusive
   of the "useTimezone=true" configuration option.) false 5.0.0
   useOldUTF8Behavior Use the UTF-8 behavior the driver did when
   communicating with 4.0 and older servers false 3.1.6
   useOnlyServerErrorMessages Don't prepend 'standard' SQLState error
   messages to error messages returned by the server. true 3.0.15
   useServerPrepStmts Use server-side prepared statements if the
   server supports them? (defaults to 'true'). true 3.1.0
   useSqlStateCodes Use SQL Standard state codes instead of 'legacy'
   X/Open/SQL state codes (true/false), default is 'true' true 3.1.3
   useStreamLengthsInPrepStmts Honor stream length parameter in
   PreparedStatement/ResultSet.setXXXStream() method calls
   (true/false, defaults to 'true')? true 3.0.2
   useTimezone Convert time/date types between client and server
   timezones (true/false, defaults to 'false')? false 3.0.2
   useUnbufferedInput Don't use BufferedInputStream for reading data
   from the server true 3.0.11
   yearIsDateType Should the JDBC driver treat the MySQL type "YEAR"
   as a java.sql.Date, or as a SHORT? true 3.1.9
   zeroDateTimeBehavior What should happen when the driver encounters
   DATETIME values that are composed entirely of zeroes (used by
   MySQL to represent invalid dates)? Valid values are 'exception',
   'round' and 'convertToNull'. exception 3.1.4

   Connector/J also supports access to MySQL via named pipes on
   Windows NT/2000/XP using the NamedPipeSocketFactory as a
   plugin-socket factory via the socketFactory property. If you don't
   use a namedPipePath property, the default of '\\.\pipe\MySQL' will
   be used. If you use the NamedPipeSocketFactory, the hostname and
   port number values in the JDBC url will be ignored. You can enable
   this feature using:
socketFactory=com.mysql.jdbc.NamedPipeSocketFactory


   Named pipes only work when connecting to a MySQL server on the
   same physical machine as the one the JDBC driver is being used on.
   In simple performance tests, it appears that named pipe access is
   between 30%-50% faster than the standard TCP/IP access.

   You can create your own socket factories by following the example
   code in com.mysql.jdbc.NamedPipeSocketFactory, or
   com.mysql.jdbc.StandardSocketFactory.

1.4.2. JDBC API Implementation Notes

   MySQL Connector/J passes all of the tests in the
   publicly-available version of Sun's JDBC compliance test suite.
   However, in many places the JDBC specification is vague about how
   certain functionality should be implemented, or the specification
   allows leeway in implementation.

   This section gives details on a interface-by-interface level about
   how certain implementation decisions may affect how you use MySQL
   Connector/J.
     * Blob
       The Blob implementation does not allow in-place modification
       (they are copies, as reported by the
       DatabaseMetaData.locatorsUpdateCopies() method). Because of
       this, you should use the corresponding
       PreparedStatement.setBlob() or ResultSet.updateBlob() (in the
       case of updatable result sets) methods to save changes back to
       the database.
       Starting with Connector/J version 3.1.0, you can emulate Blobs
       with locators by adding the property 'emulateLocators=true' to
       your JDBC URL. You must then use a column alias with the value
       of the column set to the actual name of the Blob column in the
       SELECT that you write to retrieve the Blob. The SELECT must
       also reference only one table, the table must have a primary
       key, and the SELECT must cover all columns that make up the
       primary key. The driver will then delay loading the actual
       Blob data until you retrieve the Blob and call retrieval
       methods (getInputStream(), getBytes(), and so forth) on it.
     * CallableStatement
       Starting with Connector/J 3.1.1, stored procedures are
       supported when connecting to MySQL version 5.0 or newer via
       the CallableStatement interface. Currently, the
       getParameterMetaData() method of CallableStatement is not
       supported.
     * Clob
       The Clob implementation does not allow in-place modification
       (they are copies, as reported by the
       DatabaseMetaData.locatorsUpdateCopies() method). Because of
       this, you should use the PreparedStatement.setClob() method to
       save changes back to the database. The JDBC API does not have
       a ResultSet.updateClob() method.
     * Connection
       Unlike older versions of MM.MySQL the isClosed() method does
       not ping the server to determine if it is alive. In accordance
       with the JDBC specification, it only returns true if closed()
       has been called on the connection. If you need to determine if
       the connection is still valid, you should issue a simple
       query, such as SELECT 1. The driver will throw an exception if
       the connection is no longer valid.
     * DatabaseMetaData
       Foreign Key information (getImportedKeys()/getExportedKeys()
       and getCrossReference()) is only available from InnoDB tables.
       However, the driver uses SHOW CREATE TABLE to retrieve this
       information, so when other storage engines support foreign
       keys, the driver will transparently support them as well.
     * PreparedStatement
       PreparedStatements are implemented by the driver, as MySQL
       does not have a prepared statement feature. Because of this,
       the driver does not implement getParameterMetaData() or
       getMetaData() as it would require the driver to have a
       complete SQL parser in the client.
       Starting with version 3.1.0 MySQL Connector/J, server-side
       prepared statements and binary-encoded result sets are used
       when the server supports them.
       Take care when using a server-side prepared statement with
       large parameters that are set via setBinaryStream(),
       setAsciiStream(), setUnicodeStream(), setBlob(), or setClob().
       If you want to re-execute the statement with any large
       parameter changed to a non-large parameter, it is necessary to
       call clearParameters() and set all parameters again. The
       reason for this is as follows:
          + The driver streams the large data out-of-band to the
            prepared statement on the server side when the parameter
            is set (before execution of the prepared statement).
          + Once that has been done, the stream used to read the data
            on the client side is closed (as per the JDBC spec), and
            can't be read from again.
          + If a parameter changes from large to non-large, the
            driver must reset the server-side state of the prepared
            statement to allow the parameter that is being changed to
            take the place of the prior large value. This removes all
            of the large data that has already been sent to the
            server, thus requiring the data to be re-sent, via the
            setBinaryStream(), setAsciiStream(), setUnicodeStream(),
            setBlob() or setClob() methods.
       Consequently, if you want to change the type of a parameter to
       a non-large one, you must call clearParameters() and set all
       parameters of the prepared statement again before it can be
       re-executed.
     * ResultSet
       By default, ResultSets are completely retrieved and stored in
       memory. In most cases this is the most efficient way to
       operate, and due to the design of the MySQL network protocol
       is easier to implement. If you are working with ResultSets
       that have a large number of rows or large values, and can not
       allocate heap space in your JVM for the memory required, you
       can tell the driver to stream the results back one row at a
       time.
       To enable this functionality, you need to create a Statement
       instance in the following manner:
stmt = conn.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
              java.sql.ResultSet.CONCUR_READ_ONLY);
stmt.setFetchSize(Integer.MIN_VALUE);
       The combination of a forward-only, read-only result set, with
       a fetch size of Integer.MIN_VALUE serves as a signal to the
       driver to stream result sets row-by-row. After this any result
       sets created with the statement will be retrieved row-by-row.
       There are some caveats with this approach. You will have to
       read all of the rows in the result set (or close it) before
       you can issue any other queries on the connection, or an
       exception will be thrown.
       The earliest the locks these statements hold can be released
       (whether they be MyISAM table-level locks or row-level locks
       in some other storage engine such as InnoDB) is when the
       statement completes.
       If the statement is within scope of a transaction, then locks
       are released when the transaction completes (which implies
       that the statement needs to complete first). As with most
       other databases, statements are not complete until all the
       results pending on the statement are read or the active result
       set for the statement is closed.
       Therefore, if using streaming results, you should process them
       as quickly as possible if you want to maintain concurrent
       access to the tables referenced by the statement producing the
       result set.
     * ResultSetMetaData
       The isAutoIncrement() method only works when using MySQL
       servers 4.0 and newer.
     * Statement
       When using versions of the JDBC driver earlier than 3.2.1, and
       connected to server versions earlier than 5.0.3, the
       "setFetchSize()" method has no effect, other than to toggle
       result set streaming as described above.
       MySQL does not support SQL cursors, and the JDBC driver
       doesn't emulate them, so "setCursorName()" has no effect.

1.4.3. Java, JDBC and MySQL Types

   MySQL Connector/J is flexible in the way it handles conversions
   between MySQL data types and Java data types.

   In general, any MySQL data type can be converted to a
   java.lang.String, and any numerical type can be converted to any
   of the Java numerical types, although round-off, overflow, or loss
   of precision may occur.

   Starting with Connector/J 3.1.0, the JDBC driver will issue
   warnings or throw DataTruncation exceptions as is required by the
   JDBC specification unless the connection was configured not to do
   so by using the property jdbcCompliantTruncation and setting it to
   false.

   The conversions that are always guaranteed to work are listed in
   the following table:

   Connection Properties - Miscellaneous. 
   These MySQL Data Types Can always be converted to these Java types
   CHAR, VARCHAR, BLOB, TEXT, ENUM, and SET java.lang.String,
   java.io.InputStream, java.io.Reader, java.sql.Blob, java.sql.Clob
   FLOAT, REAL, DOUBLE PRECISION, NUMERIC, DECIMAL, TINYINT,
   SMALLINT, MEDIUMINT, INTEGER, BIGINT java.lang.String,
   java.lang.Short, java.lang.Integer, java.lang.Long,
   java.lang.Double, java.math.BigDecimal
   DATE, TIME, DATETIME, TIMESTAMP java.lang.String, java.sql.Date,
   java.sql.Timestamp

   Note: round-off, overflow or loss of precision may occur if you
   choose a Java numeric data type that has less precision or
   capacity than the MySQL data type you are converting to/from.

   The ResultSet.getObject() method uses the type conversions between
   MySQL and Java types, following the JDBC specification where
   appropriate. The value returned by
   ResultSetMetaData.GetColumnClassName() is also shown below. For
   more information on the java.sql.Types classes see Java 2 Platform
   Types
   (http://java.sun.com/j2se/1.4.2/docs/api/java/sql/Types.html).

   MySQL Types to Java Types for ResultSet.getObject(). 
   MySQL Type Name Return value of GetColumnClassName Returned as
   Java Class
   BIT(1) (new in MySQL-5.0) BIT java.lang.Boolean
   BIT( > 1) (new in MySQL-5.0) BIT byte[]
   TINYINT TINYINT java.lang.Boolean if the configuration property
   tinyInt1isBit is set to true (the default) and the storage size is
   1, or java.lang.Integer if not.
   BOOL, BOOLEAN TINYINT See TINYINT, above as these are aliases for
   TINYINT(1), currently.
   SMALLINT[(M)] [UNSIGNED] SMALLINT [UNSIGNED] java.lang.Integer
   (regardless if UNSIGNED or not)
   MEDIUMINT[(M)] [UNSIGNED] MEDIUMINT [UNSIGNED] java.lang.Integer,
   if UNSIGNED java.lang.Long
   INT,INTEGER[(M)] [UNSIGNED] INTEGER [UNSIGNED] java.lang.Integer,
   if UNSIGNED java.lang.Long
   BIGINT[(M)] [UNSIGNED] BIGINT [UNSIGNED] java.lang.Long, if
   UNSIGNED java.math.BigInteger
   FLOAT[(M,D)] FLOAT java.lang.Float
   DOUBLE[(M,B)] DOUBLE java.lang.Double
   DECIMAL[(M[,D])] DECIMAL java.math.BigDecimal
   DATE DATE java.sql.Date
   DATETIME DATETIME java.sql.Timestamp
   TIMESTAMP[(M)] TIMESTAMP java.sql.Timestamp
   TIME TIME java.sql.Time
   YEAR[(2|4)] YEAR If yearIsDateType configuration property is set
   to false, then the returned object type is java.sql.Short. If set
   to true (the default) then an object of type java.sql.Date (with
   the date set to January 1st, at midnight).
   CHAR(M) CHAR java.lang.String (unless the character set for the
   column is BINARY, then byte[] is returned.
   VARCHAR(M) [BINARY] VARCHAR java.lang.String (unless the character
   set for the column is BINARY, then byte[] is returned.
   BINARY(M) BINARY byte[]
   VARBINARY(M) VARBINARY byte[]
   TINYBLOB TINYBLOB byte[]
   TINYTEXT VARCHAR java.lang.String
   BLOB BLOB byte[]
   TEXT VARCHAR java.lang.String
   MEDIUMBLOB MEDIUMBLOB byte[]
   MEDIUMTEXT VARCHAR java.lang.String
   LONGBLOB LONGBLOB byte[]
   LONGTEXT VARCHAR java.lang.String
   ENUM('value1','value2',...) CHAR java.lang.String
   SET('value1','value2',...) CHAR java.lang.String

1.4.4. Using Character Sets and Unicode

   All strings sent from the JDBC driver to the server are converted
   automatically from native Java Unicode form to the client
   character encoding, including all queries sent via
   Statement.execute(), Statement.executeUpdate(),
   Statement.executeQuery() as well as all PreparedStatement and
   CallableStatement parameters with the exclusion of parameters set
   using setBytes(), setBinaryStream(), setAsciiStream(),
   setUnicodeStream() and setBlob() .

   Prior to MySQL Server 4.1, Connector/J supported a single
   character encoding per connection, which could either be
   automatically detected from the server configuration, or could be
   configured by the user through the useUnicode and
   "characterEncoding" properties.

   Starting with MySQL Server 4.1, Connector/J supports a single
   character encoding between client and server, and any number of
   character encodings for data returned by the server to the client
   in ResultSets.

   The character encoding between client and server is automatically
   detected upon connection. The encoding used by the driver is
   specified on the server via the character_set system variable for
   server versions older than 4.1.0 and character_set_server for
   server versions 4.1.0 and newer. For more information, see Server
   Character Set and Collation
   (http://dev.mysql.com/doc/refman/5.0/en/charset-server.html).

   To override the automatically-detected encoding on the client
   side, use the characterEncoding property in the URL used to
   connect to the server.

   When specifying character encodings on the client side, Java-style
   names should be used. The following table lists Java-style names
   for MySQL character sets:

   MySQL to Java Encoding Name Translations. 
   MySQL Character Set Name Java-Style Character Encoding Name
   ascii US-ASCII
   big5 Big5
   gbk GBK
   sjis SJIS (or Cp932 or MS932 for MySQL Server < 4.1.11)
   cp932 Cp932 or MS932 (MySQL Server > 4.1.11)
   gb2312 EUC_CN
   ujis EUC_JP
   euckr EUC_KR
   latin1 ISO8859_1
   latin2 ISO8859_2
   greek ISO8859_7
   hebrew ISO8859_8
   cp866 Cp866
   tis620 TIS620
   cp1250 Cp1250
   cp1251 Cp1251
   cp1257 Cp1257
   macroman MacRoman
   macce MacCentralEurope
   utf8 UTF-8
   ucs2 UnicodeBig

   Warning.  Do not issue the query 'set names' with Connector/J, as
   the driver will not detect that the character set has changed, and
   will continue to use the character set detected during the initial
   connection setup.

   To allow multiple character sets to be sent from the client, the
   UTF-8 encoding should be used, either by configuring utf8 as the
   default server character set, or by configuring the JDBC driver to
   use UTF-8 through the characterEncoding property.

1.4.5. Connecting Securely Using SSL

   SSL in MySQL Connector/J encrypts all data (other than the initial
   handshake) between the JDBC driver and the server. The performance
   penalty for enabling SSL is an increase in query processing time
   between 35% and 50%, depending on the size of the query, and the
   amount of data it returns.

   For SSL Support to work, you must have the following:
     * A JDK that includes JSSE (Java Secure Sockets Extension), like
       JDK-1.4.1 or newer. SSL does not currently work with a JDK
       that you can add JSSE to, like JDK-1.2.x or JDK-1.3.x due to
       the following JSSE bug:
       http://developer.java.sun.com/developer/bugParade/bugs/4273544
       .html
     * A MySQL server that supports SSL and has been compiled and
       configured to do so, which is MySQL-4.0.4 or later, see Using
       Secure Connections
       (http://dev.mysql.com/doc/refman/5.0/en/secure-connections.htm
       l), for more information.
     * A client certificate (covered later in this section)

   You will first need to import the MySQL server CA Certificate into
   a Java truststore. A sample MySQL server CA Certificate is located
   in the SSL subdirectory of the MySQL source distribution. This is
   what SSL will use to determine if you are communicating with a
   secure MySQL server.

   To use Java's keytool to create a truststore in the current
   directory , and import the server's CA certificate (cacert.pem),
   you can do the following (assuming that keytool is in your path.
   The keytool should be located in the bin subdirectory of your JDK
   or JRE):
shell> keytool -import -alias mysqlServerCACert -file cacert.pem -key
store truststore


   Keytool will respond with the following information:
Enter keystore password:  *********
Owner: EMAILADDRESS=walrus@example.com, CN=Walrus, O=MySQL AB, L=Oren
burg, ST=Some
-State, C=RU
Issuer: EMAILADDRESS=walrus@example.com, CN=Walrus, O=MySQL AB, L=Ore
nburg, ST=Som
e-State, C=RU
Serial number: 0
Valid from: Fri Aug 02 16:55:53 CDT 2002 until: Sat Aug 02 16:55:53 C
DT 2003
Certificate fingerprints:
         MD5:  61:91:A0:F2:03:07:61:7A:81:38:66:DA:19:C4:8D:AB
         SHA1: 25:77:41:05:D5:AD:99:8C:14:8C:CA:68:9C:2F:B8:89:C3:34:
4D:6C
Trust this certificate? [no]:  yes
Certificate was added to keystore

   You will then need to generate a client certificate, so that the
   MySQL server knows that it is talking to a secure client:
 shell> keytool -genkey -keyalg rsa -alias mysqlClientCertificate -ke
ystore keystore

   Keytool will prompt you for the following information, and create
   a keystore named keystore in the current directory.

   You should respond with information that is appropriate for your
   situation:
Enter keystore password:  *********
What is your first and last name?
  [Unknown]:  Matthews
What is the name of your organizational unit?
  [Unknown]:  Software Development
What is the name of your organization?
  [Unknown]:  MySQL AB
What is the name of your City or Locality?
  [Unknown]:  Flossmoor
What is the name of your State or Province?
  [Unknown]:  IL
What is the two-letter country code for this unit?
  [Unknown]:  US
Is <CN=Matthews, OU=Software Development, O=MySQL AB,
 L=Flossmoor, ST=IL, C=US> correct?
  [no]:  y

Enter key password for <mysqlClientCertificate>
        (RETURN if same as keystore password):

   Finally, to get JSSE to use the keystore and truststore that you
   have generated, you need to set the following system properties
   when you start your JVM, replacing path_to_keystore_file with the
   full path to the keystore file you created,
   path_to_truststore_file with the path to the truststore file you
   created, and using the appropriate password values for each
   property.
-Djavax.net.ssl.keyStore=path_to_keystore_file
-Djavax.net.ssl.keyStorePassword=*********
-Djavax.net.ssl.trustStore=path_to_truststore_file
-Djavax.net.ssl.trustStorePassword=*********

   You will also need to set useSSL to true in your connection
   parameters for MySQL Connector/J, either by adding useSSL=true to
   your URL, or by setting the property useSSL to true in the
   java.util.Properties instance you pass to
   DriverManager.getConnection().

   You can test that SSL is working by turning on JSSE debugging (as
   detailed below), and look for the following key events:
...
 *** ClientHello, v3.1
 RandomCookie:  GMT: 1018531834 bytes = { 199, 148, 180, 215, 74, 12,
 54, 244, 0, 168, 55, 103, 215, 64, 16, 138, 225, 190, 132, 153, 2, 2
17, 219, 239, 202, 19, 121, 78 }
 Session ID:  {}
 Cipher Suites:  { 0, 5, 0, 4, 0, 9, 0, 10, 0, 18, 0, 19, 0, 3, 0, 17
 }
 Compression Methods:  { 0 }
 ***
 [write] MD5 and SHA1 hashes:  len = 59
 0000: 01 00 00 37 03 01 3D B6   90 FA C7 94 B4 D7 4A 0C  ...7..=....
...J.
 0010: 36 F4 00 A8 37 67 D7 40   10 8A E1 BE 84 99 02 D9  6...7g.@...
.....
 0020: DB EF CA 13 79 4E 00 00   10 00 05 00 04 00 09 00  ....yN.....
.....
 0030: 0A 00 12 00 13 00 03 00   11 01 00                 ...........
 main, WRITE:  SSL v3.1 Handshake, length = 59
 main, READ:  SSL v3.1 Handshake, length = 74
 *** ServerHello, v3.1
 RandomCookie:  GMT: 1018577560 bytes = { 116, 50, 4, 103, 25, 100, 5
8, 202, 79, 185, 178, 100, 215, 66, 254, 21, 83, 187, 190, 42, 170, 3
, 132, 110, 82, 148, 160, 92 }
 Session ID:  {163, 227, 84, 53, 81, 127, 252, 254, 178, 179, 68, 63,
 182, 158, 30, 11, 150, 79, 170, 76, 255, 92, 15, 226, 24, 17, 177, 2
19, 158, 177, 187, 143}
 Cipher Suite:  { 0, 5 }
 Compression Method: 0
 ***
 %% Created:  [Session-1, SSL_RSA_WITH_RC4_128_SHA]
 ** SSL_RSA_WITH_RC4_128_SHA
 [read] MD5 and SHA1 hashes:  len = 74
 0000: 02 00 00 46 03 01 3D B6   43 98 74 32 04 67 19 64  ...F..=.C.t
2.g.d
 0010: 3A CA 4F B9 B2 64 D7 42   FE 15 53 BB BE 2A AA 03  :.O..d.B..S
..*..
 0020: 84 6E 52 94 A0 5C 20 A3   E3 54 35 51 7F FC FE B2  .nR..\ ..T5
Q....
 0030: B3 44 3F B6 9E 1E 0B 96   4F AA 4C FF 5C 0F E2 18  .D?.....O.L
.\...
 0040: 11 B1 DB 9E B1 BB 8F 00   05 00                    ..........
 main, READ:  SSL v3.1 Handshake, length = 1712
 ...

   JSSE provides debugging (to STDOUT) when you set the following
   system property: -Djavax.net.debug=all This will tell you what
   keystores and truststores are being used, as well as what is going
   on during the SSL handshake and certificate exchange. It will be
   helpful when trying to determine what is not working when trying
   to get an SSL connection to happen.

1.4.6. Using Master/Slave Replication with ReplicationConnection

   Starting with Connector/J 3.1.7, we've made available a variant of
   the driver that will automatically send queries to a read/write
   master, or a failover or round-robin loadbalanced set of slaves
   based on the state of Connection.getReadOnly() .

   An application signals that it wants a transaction to be read-only
   by calling Connection.setReadOnly(true), this replication-aware
   connection will use one of the slave connections, which are
   load-balanced per-vm using a round-robin scheme (a given
   connection is sticky to a slave unless that slave is removed from
   service). If you have a write transaction, or if you have a read
   that is time-sensitive (remember, replication in MySQL is
   asynchronous), set the connection to be not read-only, by calling
   Connection.setReadOnly(false) and the driver will ensure that
   further calls are sent to the master MySQL server. The driver
   takes care of propagating the current state of autocommit,
   isolation level, and catalog between all of the connections that
   it uses to accomplish this load balancing functionality.

   To enable this functionality, use the "
   com.mysql.jdbc.ReplicationDriver " class when configuring your
   application server's connection pool or when creating an instance
   of a JDBC driver for your standalone application. Because it
   accepts the same URL format as the standard MySQL JDBC driver,
   ReplicationDriver does not currently work with
   java.sql.DriverManager -based connection creation unless it is the
   only MySQL JDBC driver registered with the DriverManager .

   Here is a short, simple example of how ReplicationDriver might be
   used in a standalone application.
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Properties;

import com.mysql.jdbc.ReplicationDriver;

public class ReplicationDriverDemo {

    public static void main(String[] args) throws Exception {
        ReplicationDriver driver = new ReplicationDriver();

        Properties props = new Properties();

        // We want this for failover on the slaves
        props.put("autoReconnect", "true");

        // We want to load balance between the slaves
        props.put("roundRobinLoadBalance", "true");

        props.put("user", "foo");
        props.put("password", "bar");

        //
        // Looks like a normal MySQL JDBC url, with a comma-separated
 list
        // of hosts, the first being the 'master', the rest being any
 number
        // of slaves that the driver will load balance against
        //

        Connection conn =
            driver.connect("jdbc:mysql://master,slave1,slave2,slave3/
test",
                props);

        //
        // Perform read/write work on the master
        // by setting the read-only flag to "false"
        //

        conn.setReadOnly(false);
        conn.setAutoCommit(false);
        conn.createStatement().executeUpdate("UPDATE some_table ...."
);
        conn.commit();

        //
        // Now, do a query from a slave, the driver automatically pic
ks one
        // from the list
        //

        conn.setReadOnly(true);

        ResultSet rs = conn.createStatement().executeQuery("SELECT a,
b,c FROM some_other_table");

         .......
    }
}

1.5. Connector/J Notes and Tips

1.5.1. Basic JDBC Concepts

   This section provides some general JDBC background.

1.5.1.1. Connecting to MySQL Using the DriverManager Interface

   When you are using JDBC outside of an application server, the
   DriverManager class manages the establishment of Connections.

   The DriverManager needs to be told which JDBC drivers it should
   try to make Connections with. The easiest way to do this is to use
   Class.forName() on the class that implements the java.sql.Driver
   interface. With MySQL Connector/J, the name of this class is
   com.mysql.jdbc.Driver. With this method, you could use an external
   configuration file to supply the driver class name and driver
   parameters to use when connecting to a database.

   The following section of Java code shows how you might register
   MySQL Connector/J from the main() method of your application:
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Notice, do not import com.mysql.jdbc.*
// or you will have problems!

public class LoadDriver {
    public static void main(String[] args) {
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations

            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            // handle the error
        }
}

   After the driver has been registered with the DriverManager, you
   can obtain a Connection instance that is connected to a particular
   database by calling DriverManager.getConnection():

   Example 1. Obtaining a connection from the DriverManager

   This example shows how you can obtain a Connection instance from
   the DriverManager. There are a few different signatures for the
   getConnection() method. You should see the API documentation that
   comes with your JDK for more specific information on how to use
   them.
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

    ... try {
            Connection conn = DriverManager.getConnection("jdbc:mysql
://localhost/test?user=monty&password=greatsqldb");

            // Do something with the Connection

           ....
        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

   Once a Connection is established, it can be used to create
   Statement and PreparedStatement objects, as well as retrieve
   metadata about the database. This is explained in the following
   sections.

1.5.1.2. Using Statements to Execute SQL

   Statement objects allow you to execute basic SQL queries and
   retrieve the results through the ResultSet class which is
   described later.

   To create a Statement instance, you call the createStatement()
   method on the Connection object you have retrieved via one of the
   DriverManager.getConnection() or DataSource.getConnection()
   methods described earlier.

   Once you have a Statement instance, you can execute a SELECT query
   by calling the executeQuery(String) method with the SQL you want
   to use.

   To update data in the database, use the executeUpdate(String SQL)
   method. This method returns the number of rows affected by the
   update statement.

   If you don't know ahead of time whether the SQL statement will be
   a SELECT or an UPDATE/INSERT, then you can use the execute(String
   SQL) method. This method will return true if the SQL query was a
   SELECT, or false if it was an UPDATE, INSERT, or DELETE statement.
   If the statement was a SELECT query, you can retrieve the results
   by calling the getResultSet() method. If the statement was an
   UPDATE, INSERT, or DELETE statement, you can retrieve the affected
   rows count by calling getUpdateCount() on the Statement instance.

   Example 2. Using java.sql.Statement to execute a SELECT query
// assume that conn is an already created JDBC connection
Statement stmt = null;
ResultSet rs = null;

try {
    stmt = conn.createStatement();
    rs = stmt.executeQuery("SELECT foo FROM bar");

    // or alternatively, if you don't know ahead of time that
    // the query will be a SELECT...

    if (stmt.execute("SELECT foo FROM bar")) {
        rs = stmt.getResultSet();
    }

    // Now do something with the ResultSet ....
} finally {
    // it is a good idea to release
    // resources in a finally{} block
    // in reverse-order of their creation
    // if they are no-longer needed

    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException sqlEx) { // ignore }

        rs = null;
    }

    if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException sqlEx) { // ignore }

        stmt = null;
    }
}

1.5.1.3. Using CallableStatements to Execute Stored Procedures

   Starting with MySQL server version 5.0 when used with Connector/J
   3.1.1 or newer, the java.sql.CallableStatement interface is fully
   implemented with the exception of the getParameterMetaData()
   method.

   See Stored Procedures and Functions
   (http://dev.mysql.com/doc/refman/5.0/en/stored-procedures.html),
   for more information on MySQL stored procedures.

   Connector/J exposes stored procedure functionality through JDBC's
   CallableStatement interface.

   Note.  Current versions of MySQL server do not return enough
   information for the JDBC driver to provide result set metadata for
   callable statements. This means that when using CallableStatement,
   ResultSetMetaData may return NULL.

   The following example shows a stored procedure that returns the
   value of inOutParam incremented by 1, and the string passed in via
   inputParam as a ResultSet:

   Example 3. Stored Procedures
CREATE PROCEDURE demoSp(IN inputParam VARCHAR(255), INOUT inOutParam
INT)
BEGIN
    DECLARE z INT;
    SET z = inOutParam + 1;
    SET inOutParam = z;

    SELECT inputParam;

    SELECT CONCAT('zyxw', inputParam);
END

   To use the demoSp procedure with Connector/J, follow these steps:
    1. Prepare the callable statement by using
       Connection.prepareCall() .
       Notice that you have to use JDBC escape syntax, and that the
       parentheses surrounding the parameter placeholders are not
       optional:
       Example 4. Using Connection.prepareCall()
import java.sql.CallableStatement;

...

    //
    // Prepare a call to the stored procedure 'demoSp'
    // with two parameters
    //
    // Notice the use of JDBC-escape syntax ({call ...})
    //

    CallableStatement cStmt = conn.prepareCall("{call demoSp(?, ?)}")
;



    cStmt.setString(1, "abcdefg");
       Note.  Connection.prepareCall() is an expensive method, due to
       the metadata retrieval that the driver performs to support
       output parameters. For performance reasons, you should try to
       minimize unnecessary calls to Connection.prepareCall() by
       reusing CallableStatement instances in your code.
    2. Register the output parameters (if any exist)
       To retrieve the values of output parameters (parameters
       specified as OUT or INOUT when you created the stored
       procedure), JDBC requires that they be specified before
       statement execution using the various
       registerOutputParameter() methods in the CallableStatement
       interface:
       Example 5. Registering output parameters
import java.sql.Types;
...
//
// Connector/J supports both named and indexed
// output parameters. You can register output
// parameters using either method, as well
// as retrieve output parameters using either
// method, regardless of what method was
// used to register them.
//
// The following examples show how to use
// the various methods of registering
// output parameters (you should of course
// use only one registration per parameter).
//

//
// Registers the second parameter as output, and
// uses the type 'INTEGER' for values returned from
// getObject()
//

cStmt.registerOutParameter(2, Types.INTEGER);

//
// Registers the named parameter 'inOutParam', and
// uses the type 'INTEGER' for values returned from
// getObject()
//

cStmt.registerOutParameter("inOutParam", Types.INTEGER);
...
    3. Set the input parameters (if any exist)
       Input and in/out parameters are set as for PreparedStatement
       objects. However, CallableStatement also supports setting
       parameters by name:
       Example 6. Setting CallableStatement input parameters
...

    //
    // Set a parameter by index
    //

    cStmt.setString(1, "abcdefg");

    //
    // Alternatively, set a parameter using
    // the parameter name
    //

    cStmt.setString("inputParameter", "abcdefg");

    //
    // Set the 'in/out' parameter using an index
    //

    cStmt.setInt(2, 1);

    //
    // Alternatively, set the 'in/out' parameter
    // by name
    //

    cStmt.setInt("inOutParam", 1);

...
    4. Execute the CallableStatement, and retrieve any result sets or
       output parameters.
       Although CallableStatement supports calling any of the
       Statement execute methods (executeUpdate(), executeQuery() or
       execute()), the most flexible method to call is execute(), as
       you do not need to know ahead of time if the stored procedure
       returns result sets:
       Example 7. Retrieving results and output parameter values
...

    boolean hadResults = cStmt.execute();

    //
    // Process all returned result sets
    //

    while (hadResults) {
        ResultSet rs = cStmt.getResultSet();

        // process result set
        ...

        hadResults = rs.getMoreResults();
    }

    //
    // Retrieve output parameters
    //
    // Connector/J supports both index-based and
    // name-based retrieval
    //

    int outputValue = cStmt.getInt(2); // index-based

    outputValue = cStmt.getInt("inOutParam"); // name-based

...

1.5.1.4. Retrieving AUTO_INCREMENT Column Values

   Before version 3.0 of the JDBC API, there was no standard way of
   retrieving key values from databases that supported auto increment
   or identity columns. With older JDBC drivers for MySQL, you could
   always use a MySQL-specific method on the Statement interface, or
   issue the query SELECT LAST_INSERT_ID() after issuing an INSERT to
   a table that had an AUTO_INCREMENT key. Using the MySQL-specific
   method call isn't portable, and issuing a SELECT to get the
   AUTO_INCREMENT key's value requires another round-trip to the
   database, which isn't as efficient as possible. The following code
   snippets demonstrate the three different ways to retrieve
   AUTO_INCREMENT values. First, we demonstrate the use of the new
   JDBC-3.0 method getGeneratedKeys() which is now the preferred
   method to use if you need to retrieve AUTO_INCREMENT keys and have
   access to JDBC-3.0. The second example shows how you can retrieve
   the same value using a standard SELECT LAST_INSERT_ID() query. The
   final example shows how updatable result sets can retrieve the
   AUTO_INCREMENT value when using the insertRow() method.

   Example 8. Retrieving AUTO_INCREMENT column values using
   Statement.getGeneratedKeys()
   Statement stmt = null;
   ResultSet rs = null;

   try {

    //
    // Create a Statement instance that we can use for
    // 'normal' result sets assuming you have a
    // Connection 'conn' to a MySQL database already
    // available

    stmt = conn.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
                                java.sql.ResultSet.CONCUR_UPDATABLE);

    //
    // Issue the DDL queries for the table for this example
    //

    stmt.executeUpdate("DROP TABLE IF EXISTS autoIncTutorial");
    stmt.executeUpdate(
            "CREATE TABLE autoIncTutorial ("
            + "priKey INT NOT NULL AUTO_INCREMENT, "
            + "dataField VARCHAR(64), PRIMARY KEY (priKey))");

    //
    // Insert one row that will generate an AUTO INCREMENT
    // key in the 'priKey' field
    //

    stmt.executeUpdate(
            "INSERT INTO autoIncTutorial (dataField) "
            + "values ('Can I Get the Auto Increment Field?')",
            Statement.RETURN_GENERATED_KEYS);

    //
    // Example of using Statement.getGeneratedKeys()
    // to retrieve the value of an auto-increment
    // value
    //

    int autoIncKeyFromApi = -1;

    rs = stmt.getGeneratedKeys();

    if (rs.next()) {
        autoIncKeyFromApi = rs.getInt(1);
    } else {

        // throw an exception from here
    }

    rs.close();

    rs = null;

    System.out.println("Key returned from getGeneratedKeys():"
        + autoIncKeyFromApi);
} finally {

    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException ex) {
            // ignore
        }
    }

    if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException ex) {
            // ignore
        }
    }
}

   Example 9. Retrieving AUTO_INCREMENT column values using SELECT
   LAST_INSERT_ID()
   Statement stmt = null;
   ResultSet rs = null;

   try {

    //
    // Create a Statement instance that we can use for
    // 'normal' result sets.

    stmt = conn.createStatement();

    //
    // Issue the DDL queries for the table for this example
    //

    stmt.executeUpdate("DROP TABLE IF EXISTS autoIncTutorial");
    stmt.executeUpdate(
            "CREATE TABLE autoIncTutorial ("
            + "priKey INT NOT NULL AUTO_INCREMENT, "
            + "dataField VARCHAR(64), PRIMARY KEY (priKey))");

    //
    // Insert one row that will generate an AUTO INCREMENT
    // key in the 'priKey' field
    //

    stmt.executeUpdate(
            "INSERT INTO autoIncTutorial (dataField) "
            + "values ('Can I Get the Auto Increment Field?')");

    //
    // Use the MySQL LAST_INSERT_ID()
    // function to do the same thing as getGeneratedKeys()
    //

    int autoIncKeyFromFunc = -1;
    rs = stmt.executeQuery("SELECT LAST_INSERT_ID()");

    if (rs.next()) {
        autoIncKeyFromFunc = rs.getInt(1);
    } else {
        // throw an exception from here
    }

    rs.close();

    System.out.println("Key returned from " + "'SELECT LAST_INSERT_ID
()': "
        + autoIncKeyFromFunc);

} finally {

    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException ex) {
            // ignore
        }
    }

    if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException ex) {
            // ignore
        }
    }
}


   Example 10. Retrieving AUTO_INCREMENT column values in Updatable
   ResultSets
   Statement stmt = null;
   ResultSet rs = null;

   try {

    //
    // Create a Statement instance that we can use for
    // 'normal' result sets as well as an 'updatable'
    // one, assuming you have a Connection 'conn' to
    // a MySQL database already available
    //

    stmt = conn.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
                                java.sql.ResultSet.CONCUR_UPDATABLE);

    //
    // Issue the DDL queries for the table for this example
    //

    stmt.executeUpdate("DROP TABLE IF EXISTS autoIncTutorial");
    stmt.executeUpdate(
            "CREATE TABLE autoIncTutorial ("
            + "priKey INT NOT NULL AUTO_INCREMENT, "
            + "dataField VARCHAR(64), PRIMARY KEY (priKey))");

    //
    // Example of retrieving an AUTO INCREMENT key
    // from an updatable result set
    //

    rs = stmt.executeQuery("SELECT priKey, dataField "
       + "FROM autoIncTutorial");

    rs.moveToInsertRow();

    rs.updateString("dataField", "AUTO INCREMENT here?");
    rs.insertRow();

    //
    // the driver adds rows at the end
    //

    rs.last();

    //
    // We should now be on the row we just inserted
    //

    int autoIncKeyFromRS = rs.getInt("priKey");

    rs.close();

    rs = null;

    System.out.println("Key returned for inserted row: "
        + autoIncKeyFromRS);

} finally {

    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException ex) {
            // ignore
        }
    }

    if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException ex) {
            // ignore
        }
    }
}




   When you run the preceding example code, you should get the
   following output: Key returned from getGeneratedKeys(): 1 Key
   returned from SELECT LAST_INSERT_ID(): 1 Key returned for inserted
   row: 2 You should be aware, that at times, it can be tricky to use
   the SELECT LAST_INSERT_ID() query, as that function's value is
   scoped to a connection. So, if some other query happens on the
   same connection, the value will be overwritten. On the other hand,
   the getGeneratedKeys() method is scoped by the Statement instance,
   so it can be used even if other queries happen on the same
   connection, but not on the same Statement instance.

1.5.2. Using Connector/J with J2EE and Other Java Frameworks

   This section describes how to use Connector/J in several contexts.

1.5.2.1. General J2EE Concepts

   This section provides general background on J2EE concepts that
   pertain to use of Connector/J.

1.5.2.1.1. Understanding Connection Pooling

   Connection pooling is a technique of creating and managing a pool
   of connections that are ready for use by any thread that needs
   them.

   This technique of pooling connections is based on the fact that
   most applications only need a thread to have access to a JDBC
   connection when they are actively processing a transaction, which
   usually take only milliseconds to complete. When not processing a
   transaction, the connection would otherwise sit idle. Instead,
   connection pooling allows the idle connection to be used by some
   other thread to do useful work.

   In practice, when a thread needs to do work against a MySQL or
   other database with JDBC, it requests a connection from the pool.
   When the thread is finished using the connection, it returns it to
   the pool, so that it may be used by any other threads that want to
   use it.

   When the connection is loaned out from the pool, it is used
   exclusively by the thread that requested it. From a programming
   point of view, it is the same as if your thread called
   DriverManager.getConnection() every time it needed a JDBC
   connection, however with connection pooling, your thread may end
   up using either a new, or already-existing connection.

   Connection pooling can greatly increase the performance of your
   Java application, while reducing overall resource usage. The main
   benefits to connection pooling are:
     * Reduced connection creation time
       Although this is not usually an issue with the quick
       connection setup that MySQL offers compared to other
       databases, creating new JDBC connections still incurs
       networking and JDBC driver overhead that will be avoided if
       connections are recycled.
     * Simplified programming model
       When using connection pooling, each individual thread can act
       as though it has created its own JDBC connection, allowing you
       to use straight-forward JDBC programming techniques.
     * Controlled resource usage
       If you don't use connection pooling, and instead create a new
       connection every time a thread needs one, your application's
       resource usage can be quite wasteful and lead to unpredictable
       behavior under load.

   Remember that each connection to MySQL has overhead (memory, CPU,
   context switches, and so forth) on both the client and server
   side. Every connection limits how many resources there are
   available to your application as well as the MySQL server. Many of
   these resources will be used whether or not the connection is
   actually doing any useful work!

   Connection pools can be tuned to maximize performance, while
   keeping resource utilization below the point where your
   application will start to fail rather than just run slower.

   Luckily, Sun has standardized the concept of connection pooling in
   JDBC through the JDBC-2.0 Optional interfaces, and all major
   application servers have implementations of these APIs that work
   fine with MySQL Connector/J.

   Generally, you configure a connection pool in your application
   server configuration files, and access it via the Java Naming and
   Directory Interface (JNDI). The following code shows how you might
   use a connection pool from an application deployed in a J2EE
   application server:

   Example 11. Using a connection pool with a J2EE application server
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.sql.DataSource;


public class MyServletJspOrEjb {

    public void doSomething() throws Exception {
        /*
         * Create a JNDI Initial context to be able to
         *  lookup  the DataSource
         *
         * In production-level code, this should be cached as
         * an instance or static variable, as it can
         * be quite expensive to create a JNDI context.
         *
         * Note: This code only works when you are using servlets
         * or EJBs in a J2EE application server. If you are
         * using connection pooling in standalone Java code, you
         * will have to create/configure datasources using whatever
         * mechanisms your particular connection pooling library
         * provides.
         */

        InitialContext ctx = new InitialContext();

         /*
          * Lookup the DataSource, which will be backed by a pool
          * that the application server provides. DataSource instance
s
          * are also a good candidate for caching as an instance
          * variable, as JNDI lookups can be expensive as well.
          */

        DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/My
SQLDB");

        /*
         * The following code is what would actually be in your
         * Servlet, JSP or EJB 'service' method...where you need
         * to work with a JDBC connection.
         */

        Connection conn = null;
        Statement stmt = null;

        try {
            conn = ds.getConnection();

            /*
             * Now, use normal JDBC programming to work with
             * MySQL, making sure to close each resource when you're
             * finished with it, which allows the connection pool
             * resources to be recovered as quickly as possible
             */

            stmt = conn.createStatement();
            stmt.execute("SOME SQL QUERY");

            stmt.close();
            stmt = null;

            conn.close();
            conn = null;
        } finally {
            /*
             * close any jdbc instances here that weren't
             * explicitly closed during normal code path, so
             * that we don't 'leak' resources...
             */

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (sqlexception sqlex) {
                    // ignore -- as we can't do anything about it her
e
                }

                stmt = null;
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (sqlexception sqlex) {
                    // ignore -- as we can't do anything about it her
e
                }

                conn = null;
            }
        }
    }
}

   As shown in the example above, after obtaining the JNDI
   InitialContext, and looking up the DataSource, the rest of the
   code should look familiar to anyone who has done JDBC programming
   in the past.

   The most important thing to remember when using connection pooling
   is to make sure that no matter what happens in your code
   (exceptions, flow-of-control, and so forth), connections, and
   anything created by them (such as statements or result sets) are
   closed, so that they may be re-used, otherwise they will be
   stranded, which in the best case means that the MySQL server
   resources they represent (such as buffers, locks, or sockets) may
   be tied up for some time, or worst case, may be tied up forever.

   What's the Best Size for my Connection Pool?

   As with all other configuration rules-of-thumb, the answer is: it
   depends. Although the optimal size depends on anticipated load and
   average database transaction time, the optimum connection pool
   size is smaller than you might expect. If you take Sun's Java
   Petstore blueprint application for example, a connection pool of
   15-20 connections can serve a relatively moderate load (600
   concurrent users) using MySQL and Tomcat with response times that
   are acceptable.

   To correctly size a connection pool for your application, you
   should create load test scripts with tools such as Apache JMeter
   or The Grinder, and load test your application.

   An easy way to determine a starting point is to configure your
   connection pool's maximum number of connections to be unbounded,
   run a load test, and measure the largest amount of concurrently
   used connections. You can then work backward from there to
   determine what values of minimum and maximum pooled connections
   give the best performance for your particular application.

1.5.2.2. Using Connector/J with Tomcat

   The following instructions are based on the instructions for
   Tomcat-5.x, available at
   http://jakarta.apache.org/tomcat/tomcat-5.0-doc/jndi-datasource-ex
   amples-howto.html which is current at the time this document was
   written.

   First, install the .jar file that comes with Connector/J in
   $CATALINA_HOME/common/lib so that it is available to all
   applications installed in the container.

   Next, Configure the JNDI DataSource by adding a declaration
   resource to $CATALINA_HOME/conf/server.xml in the context that
   defines your web application:
<Context ....>

  ...

  <Resource name="jdbc/MySQLDB"
               auth="Container"
               type="javax.sql.DataSource"/>

  <!-- The name you used above, must match _exactly_ here!

       The connection pool will be bound into JNDI with the name
       "java:/comp/env/jdbc/MySQLDB"
  -->

  <ResourceParams name="jdbc/MySQLDB">
    <parameter>
      <name>factory</name>
      <value>org.apache.commons.dbcp.BasicDataSourceFactory</value>
    </parameter>

    <!-- Don't set this any higher than max_connections on your
         MySQL server, usually this should be a 10 or a few 10's
         of connections, not hundreds or thousands -->

    <parameter>
      <name>maxActive</name>
      <value>10</value>
    </parameter>

    <!-- You don't want to many idle connections hanging around
         if you can avoid it, only enough to soak up a spike in
         the load -->

    <parameter>
      <name>maxIdle</name>
      <value>5</value>
    </parameter>

    <!-- Don't use autoReconnect=true, it's going away eventually
         and it's a crutch for older connection pools that couldn't
         test connections. You need to decide whether your applicatio
n is
         supposed to deal with SQLExceptions (hint, it should), and
         how much of a performance penalty you're willing to pay
         to ensure 'freshness' of the connection -->

    <parameter>
      <name>validationQuery</name>
      <value>SELECT 1</value>
    </parameter>

   <!-- The most conservative approach is to test connections
        before they're given to your application. For most applicatio
ns
        this is okay, the query used above is very small and takes
        no real server resources to process, other than the time used
        to traverse the network.

        If you have a high-load application you'll need to rely on
        something else. -->

    <parameter>
      <name>testOnBorrow</name>
      <value>true</value>
    </parameter>

   <!-- Otherwise, or in addition to testOnBorrow, you can test
        while connections are sitting idle -->

    <parameter>
      <name>testWhileIdle</name>
      <value>true</value>
    </parameter>

    <!-- You have to set this value, otherwise even though
         you've asked connections to be tested while idle,
         the idle evicter thread will never run -->

    <parameter>
      <name>timeBetweenEvictionRunsMillis</name>
      <value>10000</value>
    </parameter>

    <!-- Don't allow connections to hang out idle too long,
         never longer than what wait_timeout is set to on the
         server...A few minutes or even fraction of a minute
         is sometimes okay here, it depends on your application
         and how much spikey load it will see -->

    <parameter>
      <name>minEvictableIdleTimeMillis</name>
      <value>60000</value>
    </parameter>

    <!-- Username and password used when connecting to MySQL -->

    <parameter>
     <name>username</name>
     <value>someuser</value>
    </parameter>

    <parameter>
     <name>password</name>
     <value>somepass</value>
    </parameter>

    <!-- Class name for the Connector/J driver -->

    <parameter>
       <name>driverClassName</name>
       <value>com.mysql.jdbc.Driver</value>
    </parameter>

    <!-- The JDBC connection url for connecting to MySQL, notice
         that if you want to pass any other MySQL-specific parameters
         you should pass them here in the URL, setting them using the
         parameter tags above will have no effect, you will also
         need to use &amp; to separate parameter values as the
         ampersand is a reserved character in XML -->

    <parameter>
      <name>url</name>
      <value>jdbc:mysql://localhost:3306/test</value>
    </parameter>

  </ResourceParams>
</Context>

   In general, you should follow the installation instructions that
   come with your version of Tomcat, as the way you configure
   datasources in Tomcat changes from time-to-time, and unfortunately
   if you use the wrong syntax in your XML file, you will most likely
   end up with an exception similar to the following:
Error: java.sql.SQLException: Cannot load JDBC driver class 'null ' S
QL
state: null

1.5.2.3. Using Connector/J with JBoss

   These instructions cover JBoss-4.x. To make the JDBC driver
   classes available to the application server, copy the .jar file
   that comes with Connector/J to the lib directory for your server
   configuration (which is usually called default). Then, in the same
   configuration directory, in the subdirectory named deploy, create
   a datasource configuration file that ends with "-ds.xml", which
   tells JBoss to deploy this file as a JDBC Datasource. The file
   should have the following contents:
<datasources>
    <local-tx-datasource>
        <!-- This connection pool will be bound into JNDI with the na
me
             "java:/MySQLDB" -->

        <jndi-name>MySQLDB</jndi-name>
        <connection-url>jdbc:mysql://localhost:3306/dbname</connectio
n-url>
        <driver-class>com.mysql.jdbc.Driver</driver-class>
        <user-name>user</user-name>
        <password>pass</password>

        <min-pool-size>5</min-pool-size>

        <!-- Don't set this any higher than max_connections on your
         MySQL server, usually this should be a 10 or a few 10's
         of connections, not hundreds or thousands -->

        <max-pool-size>20</max-pool-size>

        <!-- Don't allow connections to hang out idle too long,
         never longer than what wait_timeout is set to on the
         server...A few minutes is usually okay here,
         it depends on your application
         and how much spikey load it will see -->

        <idle-timeout-minutes>5</idle-timeout-minutes>

        <!-- If you're using Connector/J 3.1.8 or newer, you can use
             our implementation of these to increase the robustness
             of the connection pool. -->

        <exception-sorter-class-name>com.mysql.jdbc.integration.jboss
.ExtendedMysqlExceptionSorter</exception-sorter-class-name>
        <valid-connection-checker-class-name>com.mysql.jdbc.integrati
on.jboss.MysqlValidConnectionChecker</valid-connection-checker-class-
name>

    </local-tx-datasource>
</datasources>

1.5.3. Common Problems and Solutions

   There are a few issues that seem to be commonly encountered often
   by users of MySQL Connector/J. This section deals with their
   symptoms, and their resolutions.

   Questions
     * [1]1.5.3.1: When I try to connect to the database with MySQL
       Connector/J, I get the following exception:
SQLException: Server configuration denies access to data source
SQLState: 08001
VendorError: 0
       What's going on? I can connect just fine with the MySQL
       command-line client.
     * [2]1.5.3.2: My application throws an SQLException 'No Suitable
       Driver'. Why is this happening?
     * [3]1.5.3.3: I'm trying to use MySQL Connector/J in an applet
       or application and I get an exception similar to:
SQLException: Cannot connect to MySQL server on host:3306.
Is there a MySQL server running on the machine/port you
are trying to connect to?

(java.security.AccessControlException)
SQLState: 08S01
VendorError: 0
     * [4]1.5.3.4: I have a servlet/application that works fine for a
       day, and then stops working overnight
     * [5]1.5.3.5: I'm trying to use JDBC-2.0 updatable result sets,
       and I get an exception saying my result set is not updatable.

   Questions and Answers

   1.5.3.1: When I try to connect to the database with MySQL
   Connector/J, I get the following exception: 
SQLException: Server configuration denies access to data source
SQLState: 08001
VendorError: 0

   What's going on? I can connect just fine with the MySQL
   command-line client. 

   MySQL Connector/J must use TCP/IP sockets to connect to MySQL, as
   Java does not support Unix Domain Sockets. Therefore, when MySQL
   Connector/J connects to MySQL, the security manager in MySQL
   server will use its grant tables to determine whether the
   connection should be allowed.

   You must add the necessary security credentials to the MySQL
   server for this to happen, using the GRANT statement to your MySQL
   Server. See GRANT Syntax
   (http://dev.mysql.com/doc/refman/5.0/en/grant.html), for more
   information.

   Note.  Testing your connectivity with the mysql command-line
   client will not work unless you add the --host flag, and use
   something other than localhost for the host. The mysql
   command-line client will use Unix domain sockets if you use the
   special hostname localhost. If you are testing connectivity to
   localhost, use 127.0.0.1 as the hostname instead.

   Warning.  Changing privileges and permissions improperly in MySQL
   can potentially cause your server installation to not have optimal
   security properties.

   1.5.3.2: My application throws an SQLException 'No Suitable
   Driver'. Why is this happening? 

   There are three possible causes for this error:
     * The Connector/J driver is not in your CLASSPATH, see Section
       A.2, "Installing Connector/J."
     * The format of your connection URL is incorrect, or you are
       referencing the wrong JDBC driver.
     * When using DriverManager, the jdbc.drivers system property has
       not been populated with the location of the Connector/J
       driver.

   1.5.3.3: I'm trying to use MySQL Connector/J in an applet or
   application and I get an exception similar to: 
SQLException: Cannot connect to MySQL server on host:3306.
Is there a MySQL server running on the machine/port you
are trying to connect to?

(java.security.AccessControlException)
SQLState: 08S01
VendorError: 0

   Either you're running an Applet, your MySQL server has been
   installed with the "--skip-networking" option set, or your MySQL
   server has a firewall sitting in front of it.

   Applets can only make network connections back to the machine that
   runs the web server that served the .class files for the applet.
   This means that MySQL must run on the same machine (or you must
   have some sort of port re-direction) for this to work. This also
   means that you will not be able to test applets from your local
   file system, you must always deploy them to a web server.

   MySQL Connector/J can only communicate with MySQL using TCP/IP, as
   Java does not support Unix domain sockets. TCP/IP communication
   with MySQL might be affected if MySQL was started with the
   "--skip-networking" flag, or if it is firewalled.

   If MySQL has been started with the "--skip-networking" option set
   (the Debian Linux package of MySQL server does this for example),
   you need to comment it out in the file /etc/mysql/my.cnf or
   /etc/my.cnf. Of course your my.cnf file might also exist in the
   data directory of your MySQL server, or anywhere else (depending
   on how MySQL was compiled for your system). Binaries created by
   MySQL AB always look in /etc/my.cnf and [datadir]/my.cnf. If your
   MySQL server has been firewalled, you will need to have the
   firewall configured to allow TCP/IP connections from the host
   where your Java code is running to the MySQL server on the port
   that MySQL is listening to (by default, 3306).

   1.5.3.4: I have a servlet/application that works fine for a day,
   and then stops working overnight 

   MySQL closes connections after 8 hours of inactivity. You either
   need to use a connection pool that handles stale connections or
   use the "autoReconnect" parameter (see Section A.4.1,
   "Driver/Datasource Class Names, URL Syntax and Configuration
   Properties for Connector/J").

   Also, you should be catching SQLExceptions in your application and
   dealing with them, rather than propagating them all the way until
   your application exits, this is just good programming practice.
   MySQL Connector/J will set the SQLState (see
   java.sql.SQLException.getSQLState() in your APIDOCS) to "08S01"
   when it encounters network-connectivity issues during the
   processing of a query. Your application code should then attempt
   to re-connect to MySQL at this point.

   The following (simplistic) example shows what code that can handle
   these exceptions might look like:

   Example 12. Example of transaction with retry logic
public void doBusinessOp() throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        //
        // How many times do you want to retry the transaction
        // (or at least _getting_ a connection)?
        //
        int retryCount = 5;

        boolean transactionCompleted = false;

        do {
            try {
                conn = getConnection(); // assume getting this from a
                                        // javax.sql.DataSource, or t
he
                                        // java.sql.DriverManager

                conn.setAutoCommit(false);

                //
                // Okay, at this point, the 'retry-ability' of the
                // transaction really depends on your application log
ic,
                // whether or not you're using autocommit (in this ca
se
                // not), and whether you're using transacational stor
age
                // engines
                //
                // For this example, we'll assume that it's _not_ saf
e
                // to retry the entire transaction, so we set retry c
ount
                // to 0 at this point
                //
                // If you were using exclusively transaction-safe tab
les,
                // or your application could recover from a connectio
n going
                // bad in the middle of an operation, then you would
not
                // touch 'retryCount' here, and just let the loop rep
eat
                // until retryCount == 0.
                //
                retryCount = 0;

                stmt = conn.createStatement();

                String query = "SELECT foo FROM bar ORDER BY baz";

                rs = stmt.executeQuery(query);

                while (rs.next()) {
                }

                rs.close();
                rs = null;

                stmt.close();
                stmt = null;

                conn.commit();
                conn.close();
                conn = null;

                transactionCompleted = true;
            } catch (SQLException sqlEx) {

                //
                // The two SQL states that are 'retry-able' are 08S01
                // for a communications error, and 40001 for deadlock
.
                //
                // Only retry if the error was due to a stale connect
ion,
                // communications problem or deadlock
                //

                String sqlState = sqlEx.getSQLState();

                if ("08S01".equals(sqlState) || "40001".equals(sqlSta
te)) {
                    retryCount--;
                } else {
                    retryCount = 0;
                }
            } finally {
                if (rs != null) {
                    try {
                        rs.close();
                    } catch (SQLException sqlEx) {
                        // You'd probably want to log this . . .
                    }
                }

                if (stmt != null) {
                    try {
                        stmt.close();
                    } catch (SQLException sqlEx) {
                        // You'd probably want to log this as well .
. .
                    }
                }

                if (conn != null) {
                    try {
                        //
                        // If we got here, and conn is not null, the
                        // transaction should be rolled back, as not
                        // all work has been done

                        try {
                            conn.rollback();
                        } finally {
                            conn.close();
                        }
                    } catch (SQLException sqlEx) {
                        //
                        // If we got an exception here, something
                        // pretty serious is going on, so we better
                        // pass it up the stack, rather than just
                        // logging it. . .

                        throw sqlEx;
                    }
                }
            }
        } while (!transactionCompleted && (retryCount > 0));
    }

   Note.  Use of the autoReconnect option is not recommended because
   there is no safe method of reconnecting to the MySQL server
   without risking some corruption of the connection state or
   database state information. Instead, you should use a connection
   pool which will enable your application to connect to the MySQL
   server using an available connection from the pool. The
   autoReconnect facility is deprecated, and may be removed in a
   future release.

   1.5.3.5: I'm trying to use JDBC-2.0 updatable result sets, and I
   get an exception saying my result set is not updatable. 

   Because MySQL does not have row identifiers, MySQL Connector/J can
   only update result sets that have come from queries on tables that
   have at least one primary key, the query must select every primary
   key and the query can only span one table (that is, no joins).
   This is outlined in the JDBC specification.

   Note that this issue only occurs when using updatable result sets,
   and is caused because Connector/J is unable to guarantee that it
   can identify the correct rows within the result set to be updated
   without having a unique reference to each row. There is no
   requirement to have a unique field on a table if you are using
   UPDATE or DELETE statements on a table where you can individually
   specify the criteria to be matched using a WHERE clause.

1.6. Connector/J Support

1.6.1. Connector/J Community Support

   MySQL AB provides assistance to the user community by means of its
   mailing lists. For Connector/J related issues, you can get help
   from experienced users by using the MySQL and Java mailing list.
   Archives and subscription information is available online at
   http://lists.mysql.com/java.

   For information about subscribing to MySQL mailing lists or to
   browse list archives, visit http://lists.mysql.com/. See MySQL
   Mailing Lists
   (http://dev.mysql.com/doc/refman/5.1/en/mailing-lists.html).

   Community support from experienced users is also available through
   the JDBC Forum (http://forums.mysql.com/list.php?39). You may also
   find help from other users in the other MySQL Forums, located at
   http://forums.mysql.com. See MySQL Community Support at the MySQL
   Forums (http://dev.mysql.com/doc/refman/5.1/en/forums.html).

1.6.2. How to Report Connector/J Bugs or Problems

   The normal place to report bugs is http://bugs.mysql.com/, which
   is the address for our bugs database. This database is public, and
   can be browsed and searched by anyone. If you log in to the
   system, you will also be able to enter new reports.

   If you have found a sensitive security bug in MySQL, you can send
   email to security_at_mysql.com (mailto:security_at_mysql.com).

   Writing a good bug report takes patience, but doing it right the
   first time saves time both for us and for yourself. A good bug
   report, containing a full test case for the bug, makes it very
   likely that we will fix the bug in the next release.

   This section will help you write your report correctly so that you
   don't waste your time doing things that may not help us much or at
   all.

   If you have a repeatable bug report, please report it to the bugs
   database at http://bugs.mysql.com/. Any bug that we are able to
   repeat has a high chance of being fixed in the next MySQL release.

   To report other problems, you can use one of the MySQL mailing
   lists.

   Remember that it is possible for us to respond to a message
   containing too much information, but not to one containing too
   little. People often omit facts because they think they know the
   cause of a problem and assume that some details don't matter.

   A good principle is this: If you are in doubt about stating
   something, state it. It is faster and less troublesome to write a
   couple more lines in your report than to wait longer for the
   answer if we must ask you to provide information that was missing
   from the initial report.

   The most common errors made in bug reports are (a) not including
   the version number of Connector/J or MySQL used, and (b) not fully
   describing the platform on which Connector/J is installed
   (including the JVM version, and the platform type and version
   number that MySQL itself is installed on).

   This is highly relevant information, and in 99 cases out of 100,
   the bug report is useless without it. Very often we get questions
   like, "Why doesn't this work for me?" Then we find that the
   feature requested wasn't implemented in that MySQL version, or
   that a bug described in a report has already been fixed in newer
   MySQL versions.

   Sometimes the error is platform-dependent; in such cases, it is
   next to impossible for us to fix anything without knowing the
   operating system and the version number of the platform.

   If at all possible, you should create a repeatable, stanalone
   testcase that doesn't involve any third-party classes.

   To streamline this process, we ship a base class for testcases
   with Connector/J, named 'com.mysql.jdbc.util.BaseBugReport'. To
   create a testcase for Connector/J using this class, create your
   own class that inherits from com.mysql.jdbc.util.BaseBugReport and
   override the methods setUp(), tearDown() and runTest().

   In the setUp() method, create code that creates your tables, and
   populates them with any data needed to demonstrate the bug.

   In the runTest() method, create code that demonstrates the bug
   using the tables and data you created in the setUp method.

   In the tearDown() method, drop any tables you created in the
   setUp() method.

   In any of the above three methods, you should use one of the
   variants of the getConnection() method to create a JDBC connection
   to MySQL:
     * getConnection() - Provides a connection to the JDBC URL
       specified in getUrl(). If a connection already exists, that
       connection is returned, otherwise a new connection is created.
     * getNewConnection() - Use this if you need to get a new
       connection for your bug report (i.e. there's more than one
       connection involved).
     * getConnection(String url) - Returns a connection using the
       given URL.
     * getConnection(String url, Properties props) - Returns a
       connection using the given URL and properties.

   If you need to use a JDBC URL that is different from
   'jdbc:mysql:///test', override the method getUrl() as well.

   Use the assertTrue(boolean expression) and assertTrue(String
   failureMessage, boolean expression) methods to create conditions
   that must be met in your testcase demonstrating the behavior you
   are expecting (vs. the behavior you are observing, which is why
   you are most likely filing a bug report).

   Finally, create a main() method that creates a new instance of
   your testcase, and calls the run method:
public static void main(String[] args) throws Exception {
      new MyBugReport().run();
 }

   Once you have finished your testcase, and have verified that it
   demonstrates the bug you are reporting, upload it with your bug
   report to http://bugs.mysql.com/.

1.6.3. Connector/J Change History

   The Connector/J Change History (Changelog) is located with the
   main Changelog for MySQL. See MySQL Connector/J Change History
   (http://dev.mysql.com/doc/refman/5.1/en/cj-news.html).

References

   1. file://localhost/home/mysqldoc/docs-build/mysqldoc/refman-5.0/connector-j-nolink.html#qandaitem-1-5-3-1
   2. file://localhost/home/mysqldoc/docs-build/mysqldoc/refman-5.0/connector-j-nolink.html#qandaitem-1-5-3-2
   3. file://localhost/home/mysqldoc/docs-build/mysqldoc/refman-5.0/connector-j-nolink.html#qandaitem-1-5-3-3
   4. file://localhost/home/mysqldoc/docs-build/mysqldoc/refman-5.0/connector-j-nolink.html#qandaitem-1-5-3-4
   5. file://localhost/home/mysqldoc/docs-build/mysqldoc/refman-5.0/connector-j-nolink.html#qandaitem-1-5-3-5
